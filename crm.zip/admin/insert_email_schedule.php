<?php
require '../connection.php';
session_start();

$customer_id = $_POST['customer_id'];
$subject = $_POST['subject'];
$body = $_POST['body'];
$local_time = $_POST['local_time'];

// Get customer timezone
$tz_result = $conn->query("SELECT timezone FROM customers WHERE id = $customer_id")->fetch_assoc();
$timezone = $tz_result['timezone'];

// Convert local time to UTC
$date = new DateTime($local_time, new DateTimeZone($timezone));
$date->setTimezone(new DateTimeZone('UTC'));
$scheduled_time_utc = $date->format('Y-m-d H:i:s');

// Insert
$stmt = $conn->prepare("INSERT INTO email_schedule (customer_id, subject, body, scheduled_time_utc)
                        VALUES (?, ?, ?, ?)");
$stmt->bind_param("isss", $customer_id, $subject, $body, $scheduled_time_utc);
$stmt->execute();

header("Location: view_email_schedule.php");
?>
