<?php
require '../connection.php';
require '../vendor/autoload.php'; // PHPMailer

use PHPMailer\PHPMailer\PHPMailer;

$now = date('Y-m-d H:i:s');

$result = $conn->query("SELECT e.*, c.email FROM email_schedule e
                        JOIN customers c ON e.customer_id = c.id
                        WHERE e.scheduled_time_utc <= '$now' AND e.sent = 0");

while ($row = $result->fetch_assoc()) {
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // your SMTP host
    $mail->SMTPAuth = true;
    $mail->Username = 'ajmalmoon86@gmail.com';
    $mail->Password = 'juybrmodsgavfrak';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('ajmalmoon86@gmail.com', 'SimpleTrack CRM');
    $mail->addAddress($row['email']);
    $mail->Subject = $row['subject'];
    $mail->Body = $row['body'];

    if ($mail->send()) {
        $conn->query("UPDATE email_schedule SET sent = 1 WHERE id = {$row['id']}");
    }
}
?>
