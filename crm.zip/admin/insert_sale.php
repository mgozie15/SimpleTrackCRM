<?php
require '../connection.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_id = $_POST['customer_id'];
    $product_name = $_POST['product_name'];
    $amount = $_POST['amount'];
    $sale_date = $_POST['sale_date'];
    $notes = $_POST['notes'];

    $stmt = $conn->prepare("INSERT INTO sales (customer_id, product_name, amount, sale_date, notes) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isdss", $customer_id, $product_name, $amount, $sale_date, $notes);
    $stmt->execute();

    header("Location: view_sales.php");
    exit;
}
?>