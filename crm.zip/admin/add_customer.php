<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}
include '../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $conn->prepare("INSERT INTO customers (name, email, phone, timezone) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['timezone']);
    $stmt->execute();
    $message = "Customer added successfully!";
}
?>
<?php include '../includes/sidebar.php'; ?>
<!--! [Start] Main Content !-->
<main class="nxl-container">
    <div class="nxl-content">
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10">Dashboard</h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/crm/admin/add_customer.php">Add Customers</a></li>
                    <li class="breadcrumb-item">Dashboard</li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span>Back</span>
                        </a>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="card shadow p-2">
            <div class="card border-0 shadow-sm" style="background-color: #ffffff;">
                <div class="card-header bg-white border-bottom">
                    <h4 class="mb-0 text-black">Add New Customer</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($message)): ?>
                        <div class="alert alert-success"><?= $message ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label text-black">Name</label>
                            <input name="name" class="form-control border-dark-subtle" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label text-black">Email</label>
                            <input name="email" type="email" class="form-control border-dark-subtle" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label text-black">Phone</label>
                            <input name="phone" class="form-control border-dark-subtle">
                        </div>

                        <div class="mb-3">
                            <label class="form-label text-black">Timezone</label>
                            <select name="timezone" class="form-select border-dark-subtle" required>
                                <option value="Europe/Dublin">Europe/Dublin (Ireland)</option>
                                <option value="Asia/Karachi">Asia/Karachi</option>
                                <option value="Europe/London">Europe/London</option>
                                <option value="America/New_York">America/New_York</option>
                            </select>
                        </div>

                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-dark">Add Customer</button>
                            <a href="/crm/admin/view_customers.php" class="btn btn-outline-dark">View All Customers</a>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
    <!-- [ Footer ] start -->

    <?php include '../includes/footer.php'; ?>
    <!-- [ Footer ] end -->
</main>
<!--! [End] Main Content !-->
<!--! BEGIN: Theme Customizer !-->
<?php include '../includes/theme-customization.php'; ?>
<!--! [End] Theme Customizer !-->