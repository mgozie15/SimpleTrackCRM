<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}
include '../connection.php';
$id = $_GET['id'];
$conn->query("DELETE FROM customers WHERE id = $id");
header("Location: view_customers.php");
exit;
?>
