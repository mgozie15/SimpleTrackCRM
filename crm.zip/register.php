<?php
include 'connection.php';

$name = $email = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_password')";
        if (mysqli_query($conn, $query)) {
            header("Location: index.php");
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        <?php include 'style.css'; ?>
    </style>
</head>

<body>
    <div class="container">
        <div class="Log_Cont">
            <form method="POST" action="register.php">
                <h2>Register</h2>

                <?php if (!empty($error)): ?>
                    <div style="color:red;"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="d-flex flex-column gap-1">
                    <label for="name">Full Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required placeholder="Enter your full name">
                </div>

                <div class="d-flex flex-column gap-1">
                    <label for="email">Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required placeholder="Enter your email">
                </div>

                <div class="d-flex flex-column gap-1">
                    <label for="password">Password</label>
                    <input type="password" name="password" required placeholder="Create a password">
                </div>

                <div class="d-flex flex-column gap-1">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" required placeholder="Confirm your password">
                </div>

                <div class="options d-flex justify-content-between align-items-center">
                    <label><input type="checkbox" name="terms" > I agree to the Terms & Conditions</label>
                    <a href="login.php">Already have an account? Login</a>
                </div>

                <div class="d-flex flex-column gap-1">
                    <button type="submit" name="submit-btn" class="submit-btn">Register</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>